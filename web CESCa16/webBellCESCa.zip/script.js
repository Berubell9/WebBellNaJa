document.getElementById("hi").addEventListener("click",hi);
function hi(){
    window.alert("ขอบคุณสำหรับความคิดเห็นนะค้าบ :)")
}